package hellotvxlet;

import hellotvxlet.Game;
//import javax.swing.JButton;
//import javax.swing.JFrame;

public class Main {
    
    public Main() {
     /*   JFrame start = new JFrame();
        Game startscreen = new Game();
        
        start.add(startscreen);
        start.setTitle("START GAME");
        start.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        start.pack();
        start.setVisible(true);
        start.setLocationRelativeTo(null);
   */     
 //       JButton b1 = new JButton("Button 1");     
   //     startscreen.add(b1); 
        /*
        JFrame frame = new JFrame();
        Game game = new Game();
        
        frame.add(game);
        frame.setTitle("Snake");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);*/
    }
    
    public static void main(String[] args) {
        new Main();
    }

}
